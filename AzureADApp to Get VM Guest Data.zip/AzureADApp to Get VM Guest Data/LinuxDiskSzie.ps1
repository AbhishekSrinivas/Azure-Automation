﻿echo -e "\n"

echo "#*******************************************************"

echo -e "\n"

echo "Disk Size"
df -hT 

echo -e "\n"

echo "#*******************************************************"

echo -e "\n"

echo "Current Memory Utilization"
free -m

echo -e "\n"

echo "#*******************************************************"